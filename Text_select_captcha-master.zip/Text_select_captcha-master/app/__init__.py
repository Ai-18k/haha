# !/usr/bin/env python
# -*-coding:utf-8 -*-

"""
# File       : __init__.py.py
# Time       ：2024/8/14 16:55
# Author     ：yujia
# version    ：python 3.6
# Description：
"""
from src import captcha

# 初始化时候加载模型
cap_model = captcha.TextSelectCaptcha()